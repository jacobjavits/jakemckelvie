$(".musician a").hover(function() {
  $(".portrait").toggleClass("flip");
});
